f3-boilerplate application
==========================

(c) Copyright 2013 Vijay Mahrra <vijay.mahrra@gmail.com>

