# APPLICATION TEAM

* Vijay Mahrra -- vijay.mahrra@gmail.com -- @vijinh0

# CONTRIBUTORS

* Christian Knuth -- https://github.com/ikkez
* Stefano Ricci -- http://www.sharmpro.com

# SOFTWARE PROJECTS

* Fat-Free Framework - http://fatfreeframework.com/
* HTML5 ★ BOILERPLATE - http://html5boilerplate.com/

