-- 2013-07-21 Add new column
-- SOME SQL STATEMENTS below

-- 2013-07-21 12:10 Remove new column
-- SOME MORE SQL BELOW
