<?php
// f3-boilerplate application
// @see https://github.com/vijinho/f3-boilerplate
chdir(realpath(__DIR__ . '/../app'));
require_once 'bootstrap.php';
